package com.company;
import java.util.*;

public class myCalc {

    public static void main(String[] args) {

            Scanner in = new Scanner(System.in);
            System.out.println("Input:");
            String input = in.nextLine().replace(" ","");

            Main expression = new Main();
            System.out.println(expression.calc(input));
    }

}

class Main {



    public String calc(String inputString) {

       try{
           int firstNumber, secondNumber;

           if (inputString.length() < 3){
               throw new Exception();
           }
           if(inputString.contains(",") || inputString.contains(".")){
               throw new Exception();
           }
           if (inputString.substring(inputString.length()-1).matches("[+-/*]") ){
               throw new Exception();
           }

           String[] num = inputString.split("[+-/*]");

           if (num.length > 2) throw new Exception();

           char operation = inputString.charAt(num[0].length());
           boolean isRoman = isRomanNumber(num);

           if (isRoman){
                firstNumber = romanToArabic(num[0].toUpperCase(Locale.ROOT));
                secondNumber = romanToArabic(num[1].toUpperCase(Locale.ROOT));
           } else {
                firstNumber = Integer.parseInt(num[0]);
                secondNumber = Integer.parseInt(num[1]);
           }

           int result = calculate(firstNumber, secondNumber, operation);

           if(isRoman) return arabicToRoman(result);

           return String.valueOf(result);
       }catch (Exception ex){
           return "Исключение";
       }
    }

    int romanToArabic (String number) {
        String[] roman = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX","X"};
        int i = 0;

        do {
            if (roman[i].equals(number)) {
                return i + 1;
            }
            i++;
        } while (i < roman.length);

        return 0;
    }

    String arabicToRoman(int inputValue) throws Exception {
        String[] romanNumber = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX",
                "XXI", "XXII", "XXIII", "XXIV", "XXV", "XXVI", "XXVII", "XXVIII", "XXIX", "XXX", "XXXI", "XXXII", "XXXIII", "XXXIV", "XXXV", "XXXVI", "XXXVII", "XXXVIII", "XXXIX", "XL",
                "XLI", "XLII", "XLIII", "XLIV", "XLV", "XLVI", "XLVII", "XLVIII", "XLIX", "L", "LI", "LII", "LIII", "LIV", "LV", "LVI", "LVII", "LVIII", "LIX", "LX",
                "LXI", "LXII", "LXIII", "LXIV", "LXV", "LXVI", "LXVII", "LXVIII", "LXIX", "LXX",
                "LXXI", "LXXII", "LXXIII", "LXXIV", "LXXV", "LXXVI", "LXXVII", "LXXVIII", "LXXIX", "LXXX",
                "LXXXI", "LXXXII", "LXXXIII", "LXXXIV", "LXXXV", "LXXXVI", "LXXXVII", "LXXXVIII", "LXXXIX", "XC",
                "XCI", "XCII", "XCIII", "XCIV", "XCV", "XCVI", "XCVII", "XCVIII", "XCIX", "C"
        };

        if (inputValue < 1) throw new Exception();

        return romanNumber[inputValue-1];
    }

    int calculate(int a, int b, char operation) throws Exception {
        int result = 0;
         switch (operation){
             case'+': result = a + b;
                 break;
             case'-': result = a - b;
              break;
             case'*': result= a * b;
                 break;
             case'/': result = Math.round(a/b);
                 break;
             default: throw new Exception();
        };
        return result;
    }

    boolean isRomanNumber (String[] num) throws Exception {

        if(num[0].matches("^0?([1-9]|10)$") && num[1].matches("^0?([1-9]|10)$")){
            return false;
        } else if(num[0].matches("(X|IX|IV|V?I{0,3})") && num[1].matches("(X|IX|IV|V?I{0,3})")){
            return true;
        }
        throw new Exception();
    }
}